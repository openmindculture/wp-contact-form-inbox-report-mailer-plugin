<?php

function openmindculture_generate_report() {
	$report = '';

	$args = array(
		'post_type'    => 'flamingo_inbound',
		/*
		'date_query'   => array(
			'after'    => '-2 day',
		), */
		// 'orderby'        => array( 'date', 'post_status' ),
		'order'          => 'DESC',
		'posts_per_page' => -1,
	);

	$the_query = new WP_Query( $args );

	if ( $the_query->have_posts() ) :
		$report .= '<h1>';
		$report .= esc_html(
			'Contact Form Inbox Report Mailer',
			'openmindculture-openmindculture-contact-form-inbox-report-mailer'
		);
		$report .= '</h1>';
		$report .= '<table>';
		while ( $the_query->have_posts() ) :
			$the_query->the_post();
			$report .= '  <tr>';
			$report .= '    <td>';
			$report .= esc_html( get_field('subject', get_the_ID()) );
			$report .= '    </td>';
			$report .= '    <td>';
			$report .= esc_html( get_field('from', get_the_ID()) );
			$report .= '    </td>';
			$report .= '    <td>';
			$report .= get_the_date();
			$report .= '    </td>';
			$report .= '    <td>';
			if ( get_field('post_status', get_the_ID()) === 'spam' ) :
				$report .= '      <b>spam?</b>';
			endif;
			$report .= '    </td>';
			$report .= '  </tr>';
		endwhile;
		$report .= '</table>';
	endif;
	if ( !empty($report) ) {
		$report .= esc_html(
			'Automatic report sent from ',
			'openmindculture-openmindculture-contact-form-inbox-report-mailer'
		);
		$report .= get_site_url();
		$report .= ' ';
		$report .= esc_html(
			'by the plugin Contact Form Inbox Report Mailer',
			'openmindculture-openmindculture-contact-form-inbox-report-mailer'
		);
		$report .= '.<br>';
		$report .= esc_html(
			'Disable the plugin to unsubscribe.',
			'openmindculture-openmindculture-contact-form-inbox-report-mailer'
		);
	}
	return $report;
}
